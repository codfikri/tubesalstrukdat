#ifndef load_H
#define load_H

#include <stdio.h>
#include <unistd.h>
#include "../player/player.h"

void LoadFile(PlayerList * LP);

#endif