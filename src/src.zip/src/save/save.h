#ifndef save_H
#define save_H

#include <stdio.h>
#include <unistd.h>
#include "../player/player.h"

void saveData(PlayerList PL);

#endif